//
//  NextViewController.swift
//  popViewController
//
//  Created by shaimaa on 20/01/1441 AH.
//  Copyright © 1441 shaimaa. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  

}
