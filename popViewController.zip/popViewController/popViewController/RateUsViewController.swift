//
//  RateUsViewController.swift
//  popViewController
//
//  Created by shaimaa on 20/01/1441 AH.
//  Copyright © 1441 shaimaa. All rights reserved.
//

import UIKit

class RateUsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

    @IBAction func back(_ sender: Any) {
         self.dismiss(animated: true, completion: nil)
        
    }
}
