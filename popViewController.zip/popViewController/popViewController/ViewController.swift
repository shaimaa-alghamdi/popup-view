//
//  ViewController.swift
//  popViewController
//
//  Created by shaimaa on 20/01/1441 AH.
//  Copyright © 1441 shaimaa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    /*in the first click, it will show popup view
    and in second click, it will be going to another view controller.
    */
    
    var popView = false
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func goToNext(_ sender: Any) {
        // add any condition here
        if popView == false {
           performSegue(withIdentifier: "popView", sender: nil)
            popView = true
        }else{
            // add any condition here
            performSegue(withIdentifier: "anotherPop", sender: nil)
            popView = false
        }
        
    }
}

